#ifndef VI_2048_GAME_H
#define VI_2048_GAME_H

namespace vi
{
    unsigned long step_game();
    void          configure(unsigned depth_limit, float probability_limit);
    void          reset_game();
}

#endif // VI_2048_GAME_H

